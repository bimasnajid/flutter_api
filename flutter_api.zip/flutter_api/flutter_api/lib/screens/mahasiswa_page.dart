import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/mahasiswa.dart';

class MahasiswaPage extends StatefulWidget {
  @override
  _MahasiswaPageState createState() => _MahasiswaPageState();
}

class _MahasiswaPageState extends State<MahasiswaPage> {
  late Future<List<Mahasiswa>> mahasiswa;

  @override
  void initState() {
    super.initState();
    mahasiswa = ApiService.fetchMahasiswa();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Data Mahasiswa")),
      body: FutureBuilder<List<Mahasiswa>>(
        future: mahasiswa,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final mhs = snapshot.data![index];
                return ListTile(title: Text(mhs.nama), subtitle: Text(mhs.nim));
              },
            );
          } else if (snapshot.hasError) {
            return Center(child: Text("Error"));
          }
          return Center(child: CircularProgressIndicator());
        },
      ),
    );
  }
}
