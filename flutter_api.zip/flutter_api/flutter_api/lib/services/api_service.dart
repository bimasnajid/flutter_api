import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/mahasiswa.dart';

class ApiService {
  static const String baseUrl = "http://10.0.2.2/api/mahasiswa";

  // GET
  static Future<List<Mahasiswa>> fetchMahasiswa() async {
    final response = await http.get(Uri.parse(baseUrl));

    if (response.statusCode == 200) {
      List data = json.decode(response.body);
      return data.map((e) => Mahasiswa.fromJson(e)).toList();
    } else {
      throw Exception("Gagal mengambil data");
    }
  }

  // POST
  static Future<void> addMahasiswa(
    String nama,
    String nim,
    String jurusan,
  ) async {
    await http.post(
      Uri.parse(baseUrl),
      headers: {"Content-Type": "application/json"},
      body: json.encode({"nama": nama, "nim": nim, "jurusan": jurusan}),
    );
  }
}
